(()=>{if(window.__HDR__)return;window.__HDR__=true;const y=document.getElementById('year');if(y)y.textContent=new Date().getFullYear();})();
