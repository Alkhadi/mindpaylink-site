(function(){
  window.__START_FIX_OFF=true;
  document.querySelectorAll('button:not([type])').forEach(function(b){ b.setAttribute('type','button'); });
})();
