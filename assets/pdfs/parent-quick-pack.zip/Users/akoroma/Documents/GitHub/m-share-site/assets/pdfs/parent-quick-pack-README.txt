Parent Quick Pack (Autism, UK)

What’s inside:
- Autism — Parent Quick Guide (UK).pdf
- FCT — Functional Communication (handout)
- Choice-making (handout)
- Emotion check-in (handout)
- One-page profile (handout)
- Video modelling (handout)
- Time delay prompting (handout)
- Self-management checklists (handout)

Notes:
- Educational information only; not medical advice.
- For personal use. Check local policies before sharing externally.

Built: 18 Oct 2025